$(document).ready(function(){
    $(".main_mnu_button").click(function(){
        $("#nav").slideToggle("slow");
        console.log('ok');
    });
});	